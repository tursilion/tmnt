20120901

This is a silly little game I made back in... it must have been 1988 or 1989. I had it posted before, but there was no good way to get a copy of The Missing Link to run it. Now there is, and I replaced the shareware title page with something a little nicer. ;)

The game is pretty slow and doesn't have much depth, but, it's a thing!

---

How to use:

You will need Extended BASIC, the Missing Link, 32k, joystick and a Disk system.

TML 2.0 for Extended BASIC is included with kind permssion from Harry Wilhelm.

---

To run the game, insert the TMNT disk into DSK1 (it MUST be DSK1).

First, enter: RUN "DSK1.TML"

When the cursor returns, enter: RUN "DSK1.TMNT"

The game will begin and automatically load images from DSK1 as it proceeds.

Use the joystick to move/choose, and the fire button to select/advance/attack.

You will select one of the four turtles, and face against three bosses in one-on-one battles.

Bebop is a mutated boar, and will attack with punches and kicks.

Rocksteady is a mutated rhino, and will attack with machine gun, kicks, and charges.

Shredder is a ninja human, and will attack with de-mutagen ray, punches, and jump kicks.

If you are hit too many times and lose all your health, or are struck by the de-mutagen ray, you will revert to a normal turtle. If there are turtles remaining, you get another chance.

